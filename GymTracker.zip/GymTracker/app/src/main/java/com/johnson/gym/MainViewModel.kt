package com.johnson.gym

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
}