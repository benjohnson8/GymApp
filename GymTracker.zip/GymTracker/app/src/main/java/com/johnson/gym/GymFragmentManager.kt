package com.johnson.gym

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.johnson.gym.databinding.ActivityMainBinding

class GymFragmentManager(private val activity: ActivityMainBinding, private val supportHomeFragmentManager: FragmentManager) {

    fun startFragment(fragment: Fragment, popBackStack: Boolean = false, animation: Boolean = false) {
        val transaction = supportHomeFragmentManager.beginTransaction()
        transaction.add(activity.frameLayout.id, fragment)
        transaction.addToBackStack(null)

        if (popBackStack) {
            val x = 0
            while (x != supportHomeFragmentManager.backStackEntryCount) {
                supportHomeFragmentManager.popBackStackImmediate()
            }
        }
        transaction.commit()
    }



}