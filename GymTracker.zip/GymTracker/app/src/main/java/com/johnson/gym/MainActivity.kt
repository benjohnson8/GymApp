package com.johnson.gym

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.johnson.gym.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding
    private lateinit var fragmentManager : GymFragmentManager
    private val viewModel: MainViewModel by viewmodel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Inflate and bind the view
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)
        //Create fragment manager
        fragmentManager = GymFragmentManager(binding,supportFragmentManager)
        //bind viewModel
        viewModel = MainViewModel by viewModels
    }
}